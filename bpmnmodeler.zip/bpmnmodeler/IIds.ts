import {ISeed} from './index';

export interface IIds {
  _seed?: ISeed;
}
