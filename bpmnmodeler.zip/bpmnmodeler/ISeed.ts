import {IModdleElement} from './index';

export interface ISeed {
  hats?: Array<IModdleElement>;
}
