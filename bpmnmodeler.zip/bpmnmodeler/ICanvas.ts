import {IShape} from './IShape';

export interface ICanvas {
  getRootElement(): IShape;
}
