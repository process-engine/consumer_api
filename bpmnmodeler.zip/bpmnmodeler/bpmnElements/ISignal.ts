export interface ISignal {
  id: string;
  name: string;
}
