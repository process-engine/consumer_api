import {IModdleElement} from './IModdleElement';

export interface IConditionExpression extends IModdleElement {
  body?: string;
}
