export interface IProperty {
  $type?: string;
  name?: string;
  value?: string;
}
