export enum ElementDistributeOptions {
  HORIZONTAL = 'horizontal',
  VERTICAL = 'vertical',
}
